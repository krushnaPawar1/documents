import sqlite3
conn=sqlite3.connect("data.db")
cur=conn.cursor()
cur.execute("create table food (id int primary key,name text,protein int ,carbohydrates int ,fat int ,calories int )")
# cur.execute("create table log_date   (id int primary key,entrydate date )")
cur.execute("create table food_date (id int primary key ,log_date_id int)")
# cur.execute("alter table log_date(id int primary key,entrydate DATE )")
cur.execute("create table datetable(id int primary key,entrydate date  not null)")
# cur.commit()
cur.close()
conn.close()

