from flask import Flask,render_template,url_for,request
import sqlite3
from datetime import datetime
app=Flask(__name__)




@app.route("/",methods=["POST","GET"])
def fun():
    conn=sqlite3.connect('data.db')
    cur=conn.cursor()
    if request.method=="POST":
        date=request.form['date']
        cur.execute('insert into datetable(entrydate) values(?)',[date])
        conn.commit()
    cur.execute("SELECT entrydate from datetable" )
    t=cur.fetchall()
    prety_res=[]
    for i in  range(len(t)):
        date=t[i][0]
        if date=="":
            continue
        else:
            date1=datetime.strptime(date,"%Y-%m-%d")
            v=datetime.strftime(date1,"%B %d ,%y")
            prety_res.append(v)

    return render_template("home.html",r=prety_res[::-1])













@app.route('/view/<date>')
def view():
    return render_template('day.html')






@app.route("/food", methods=["GET","POST"])
def food():
    conn=sqlite3.connect('data.db')
    cur=conn.cursor()
    if request.method=="POST":
        #  return "None"
        name=request.form['name']
        protein=int(request.form['protein'])
        carbohydrates=int(request.form['carbohydrates'])
        fat=int(request.form['fat'])
        calories=protein*4+carbohydrates*4+fat*9      
        cur.execute('Insert into food (name,protein,carbohydrates,fat,calories) values(?,?,?,?,?)',(name,protein,carbohydrates,fat,calories))
        conn.commit()

    cur.execute('select name,protein,carbohydrates,fat,calories from food')
    res=cur.fetchall()
    cur.close()
    conn.close()
    return render_template('add_food.html',res=res)
app.run(debug=True)